package com.first.ahikarov

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

// הכיתה מקבלת רשימה של נתונים (MediaItem) שהגדרנו במודל
class MediaAdapter(private val items: List<MediaItem>) : RecyclerView.Adapter<MediaAdapter.MediaViewHolder>() {

    // חלק א': ה-ViewHolder ("מחזיק המפתחות")
    // התפקיד שלו: למצוא את ה-ImageView בתוך ה-XML פעם אחת ולזכור אותו
    class MediaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.item_image)
        // שים לב: item_image זה ה-ID שנתנו לתמונה בתוך item_square_image.xml
    }

    // חלק ב': onCreateViewHolder ("מפעל הקופסאות")
    // התפקיד שלו: ליצור כרטיס חדש (View) מתוך קובץ ה-XML
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MediaViewHolder {
        // כאן אנחנו טוענים את קובץ העיצוב שיצרת: item_square_image
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_square_image, parent, false)
        return MediaViewHolder(view)
    }

    // חלק ג': onBindViewHolder ("האורז")
    // התפקיד שלו: לקחת כרטיס קיים, ולהכניס לתוכו את התמונה הנכונה לפי המיקום ברשימה
    override fun onBindViewHolder(holder: MediaViewHolder, position: Int) {
        val currentItem = items[position] // לוקח את הפריט הנוכחי (למשל: תמונה מספר 3)
        holder.imageView.setImageResource(currentItem.imageRes) // שם את התמונה בתוך הכרטיס
    }

    // חלק ד': getItemCount ("ספירת מלאי")
    // התפקיד שלו: להגיד לרשימה כמה פריטים יש סך הכל
    override fun getItemCount(): Int {
        return items.size
    }
}