package com.first.ahikarov

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// כאן אנחנו מקבלים רשימה של משפטים (QuoteItem)
class QuoteAdapter(private val items: List<QuoteItem>) : RecyclerView.Adapter<QuoteAdapter.QuoteViewHolder>() {

    // 1. ViewHolder - מחפש את הטקסט בתוך הכרטיס
    class QuoteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val quoteTextView: TextView = itemView.findViewById(R.id.quote_text)
        // שים לב: quote_text זה ה-ID שנתנו בתוך item_quote_card.xml
    }

    // 2. onCreateViewHolder - יוצר כרטיס מלבני חדש
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuoteViewHolder {
        // טוען את השבלונה של המשפטים: item_quote_card
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_quote_card, parent, false)
        return QuoteViewHolder(view)
    }

    // 3. onBindViewHolder - מכניס את הטקסט והצבע לכרטיס
    override fun onBindViewHolder(holder: QuoteViewHolder, position: Int) {
        val currentItem = items[position]

        // מעדכן את הטקסט
        holder.quoteTextView.text = currentItem.text

        // (אופציונלי) משנה את צבע הרקע לפי מה שהגדרנו במודל
        // אם הצבע הוא קוד הקסדצימלי כמו "#FF0000"
        try {
            holder.quoteTextView.setBackgroundColor(Color.parseColor(currentItem.color))
        } catch (e: Exception) {
            // אם הצבע לא תקין, לא נורא, יישאר הצבע המקורי
        }
    }

    // 4. ספירת מלאי
    override fun getItemCount(): Int {
        return items.size
    }
}