package com.first.ahikarov

//model for photo and music
data class MediaItem(
    val id: Int,
    val imageRes: Int,
    val title: String
)

// model for quote
data class QuoteItem(
    val id: Int,
    val text: String,
    val color: String
)